require "test_helper"

class PlayGamesControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get play_games_new_url
    assert_response :success
  end

  test "should get create" do
    get play_games_create_url
    assert_response :success
  end

  test "should get show" do
    get play_games_show_url
    assert_response :success
  end
end
