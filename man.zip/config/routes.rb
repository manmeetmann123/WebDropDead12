Rails.application.routes.draw do
  get 'play_games/new'
  get 'play_games/create'
  get 'play_games/show'
  get 'users/new'
  get 'users/create'
  get 'sessions/new'
  get 'sessions/create'
  get 'sessions/destroy'
  get 'login', to: 'sessions#new'
  post 'login', to: 'sessions#create'
  delete 'logout', to: 'sessions#destroy'
  get 'user_page', to: 'user_page#show'
  get 'play_game', to: 'play_game#show'
  get 'signup', to: 'users#new'
  post 'signup', to: 'users#create'
  get 'play_game', to: 'play_games#new'
  post 'play_game', to: 'play_games#create'
  get 'play_game/show', to: 'play_games#show', as: 'show_game'
  post '/play_games', to: 'play_games#create', as: 'play_games'

  resources :play_games, only: [:new, :create, :show]

  # set root path
  root 'sessions#new'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Defines the root path route ("/")
  # root "posts#index"
end
