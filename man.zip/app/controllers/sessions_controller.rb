# app/controllers/sessions_controller.rb
class SessionsController < ApplicationController
  def new
  end

  def create
    redirect_to play_games_new_path
    # user = User.find_by(email: params[:session][:email])

    # if user && user.authenticate(params[:session][:password])
    #   redirect_to determine_redirect_path(user)
    # else
    #   flash.now[:alert] = 'Invalid email/password combination'
    #   render 'new'
    # end
  end

  def destroy
    # Implement sign-out logic if needed
  end

  private

  def determine_redirect_path(user)
    user_page_exists?(user) ? user_page_path(user) : play_game_path
  end

  def user_page_exists?(user)
    # Replace this with your logic to check if the user has a user page
    # For example, if there is a boolean attribute 'has_user_page' on the user model:
    # user.has_user_page?
    true
  end
end

