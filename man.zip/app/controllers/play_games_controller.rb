class PlayGamesController < ApplicationController
  def create
    # binding.pry
    Rails.logger.debug("Processing create action...")
    num_players = params[:num_players].to_i
    num_die_sides = params[:num_die_sides].to_i
    num_dice = params[:num_dice].to_i
    
    @game_result = run_auto_drop_dead_game(num_players, num_die_sides, num_dice)
    
    if @game_result
      redirect_to play_games_show_path(player: @game_result[0], points: @game_result[1])
    else
      flash[:error] = "Error running the game."
      render 'new'
    end
    Rails.logger.debug("Finished processing create action.")
  end
  def show
    @player = params[:player]
    @points = params[:points].to_i
  end
  # private
  # require 'pry'
  def run_auto_drop_dead_game(num_players, num_die_sides, num_dice)
    players = (1..num_players).to_a
    player_points = Hash.new(0)
    player_dice = Hash.new { |hash, key| hash[key] = Array.new(num_dice) { rand(1..num_die_sides) } }
    iteration = 0
    while players.length > 0
      changes_made = false
  
      players.each do |player|
        roll_result = player_dice[player]
  
        if roll_result.include?(2) || roll_result.include?(5)
          remove_dice(player_dice, player)
          changes_made = true
        else
          points = roll_result.sum
          player_points[player] += points
        end
  
        if player_dice[player].empty?
          drop_dead(player, player_points)
          players.delete(player)
          changes_made = true
        end
      end
      iteration += 1
      Rails.logger.debug("Iteration #{iteration}, Changes made: #{changes_made}")
  
      break unless changes_made
    end
  
    determine_winner(player_points)
  end
  
  def remove_dice(player_dice, player)
    player_dice[player] = player_dice[player].reject { |die| [2, 5].include?(die) }
  end
  
  def drop_dead(player, player_points)
    puts "Player #{player} drops dead! Total points: #{player_points[player]}"
  end
  
  def determine_winner(player_points)
    winner = player_points.max_by { |_, points| points }
    puts "Player #{winner[0]} wins with #{winner[1]} points!"
    winner
  end
  
end



