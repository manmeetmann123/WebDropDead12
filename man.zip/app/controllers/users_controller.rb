
class UsersController < ApplicationController
  def new
    @user = User.new
  end

  def create
    @user = User.new(user_params)

    if @user.save
      # Successful sign-up
      initialize_user_attributes(@user)
      redirect_to sessions_new_path(@user)
    else
      render 'new'
    end
  end

  private

  def user_params
    params.require(:user).permit(:username, :email, :password)
  end

  def determine_redirect_path(user)
    user_page_exists?(user) ? user_page_path(user) : play_game_path
  end

  def initialize_user_attributes(user)
    # Provide the user with three quarters and three six-sided white dice
    # Set overall points to 0
    user.update(overall_points: 0, quarters: 3, white_dice: 3)
  end

  def user_page_exists?(user)
    # Replace this with your logic to check if the user has a user page
    # For example, if there is a boolean attribute 'has_user_page' on the user model:
    # user.has_user_page?
    true
  end
end

