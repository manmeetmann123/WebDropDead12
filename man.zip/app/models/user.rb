class User < ApplicationRecord
    attribute :username, :string
    attribute :email, :string
    attribute :password, :string
    attribute :overall_points, :integer
    attribute :quarters, :integer
    attribute :white_dice, :integer
    attribute :black_dice, :integer
    attribute :red_dice, :integer
    attribute :green_dice, :integer
    attribute :blue_dice, :integer
    attribute :purple_dice, :integer
    attribute :yellow_dice, :integer
    attribute :orange_dice, :integer
    attribute :pink_dice, :integer
    attribute :brown_dice, :integer
    
end
